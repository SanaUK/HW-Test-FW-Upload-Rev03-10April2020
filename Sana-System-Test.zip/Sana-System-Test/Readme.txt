This directory should contain the following files:

03/31/2020  04:07 PM           272,804 FW-0001-NOAPP-UNSECBLE-V01.05.01-20200324_17h11m39s.hex
03/31/2020  04:07 PM           272,759 FW-0003-NOAPP-UNSECBLE-V01.05.01-20200324_17h11m39s.hex
03/31/2020  04:07 PM           272,804 FW-0005-APP-UNSECBLE-V01.05.01-20200324_17h11m39s.hex
03/31/2020  04:07 PM           272,759 FW-0006-APP-UNSECBLE-V01.05.01-20200324_17h11m39s.hex
02/09/2020  08:08 PM               645 PgmAll.bat
03/24/2020  09:42 AM               653 PgmAll_ShamApp.bat
03/24/2020  09:43 AM               655 PgmAll_ShamNoApp.bat
03/24/2020  09:43 AM               656 PgmAll_TherapyApp.bat
03/24/2020  09:43 AM               658 PgmAll_TherapyNoApp.bat
04/09/2020  05:35 PM               133 PgmFW.bat
04/09/2020  05:36 PM               133 PgmFW_ShamApp.bat
04/09/2020  05:36 PM               135 PgmFW_ShamNoApp.bat
04/09/2020  05:37 PM               133 PgmFW_TherapyApp.bat
04/09/2020  05:37 PM               135 PgmFW_TherapyNoApp.bat
04/09/2020  05:34 PM               216 PgmHW.bat
03/31/2020  08:59 AM             1,852 Readme.txt
06/30/2017  04:23 AM           390,362 s132_nrf52_5.0.0_softdevice.hex
04/09/2020  05:22 PM           238,599 SanaHWTest-09Apr2020.hex
04/09/2020  05:29 PM    <DIR>          VS1000-Audio-Files

These batch files should be invoked to program, test and firmware-load the Sana Mask devices:

PgmAll.bat 	: Equivalent to PgmAll_TherapyApp.bat
PgmAll_ShamApp.bat	: Loads standard hardware test, then loads Sham/App-Controlled firmware
PgmAll_ShamNoApp.bat	: Loads standard hardware test, then loads Sham/NoApp-Controlled firmware
PgmAll_TherapyApp.bat	: Loads standard hardware test, then loads Therapy/App-Controlled firmware
PgmAll_TherapyNoApp.bat	: Loads standard hardware test, then loads Therapy/NoApp-Controlled firmware

